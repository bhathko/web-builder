import { Component } from '@angular/core';
import { SharedModule } from '../../shared/shared-module';

@Component({
  selector: 'app-untitled-project',
  templateUrl: './untitled-project.component.html',
  styleUrls: ['./untitled-project.component.scss'],
  imports: [SharedModule]
})
export class UntitledProjectComponent {
  // Component logic here
}