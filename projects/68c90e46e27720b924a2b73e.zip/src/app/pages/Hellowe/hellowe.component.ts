import { Component } from '@angular/core';
import { SharedModule } from '../../shared/shared-module';

@Component({
  selector: 'app-hellowe',
  templateUrl: './hellowe.component.html',
  styleUrls: ['./hellowe.component.scss'],
  imports: [SharedModule]
})
export class HelloweComponent {
  // Component logic here
}